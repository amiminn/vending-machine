<template lang="">
    <img src="/icon/loading.svg" alt="" class="w-32" />
</template>
