<template lang="">
    <div class="p-4 border-4 border-gray-200 border-dashed rounded-lg bg-white">
        <slot></slot>
    </div>
</template>
