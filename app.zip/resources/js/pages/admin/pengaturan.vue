<template lang="">
    <layout>
        <ha>Pengaturan</ha>
    </layout>
</template>
<script>
import layout from "./layout.vue";
export default {
    components: { layout },
};
</script>
<style lang=""></style>
