<template lang="">
    <div>scan</div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
