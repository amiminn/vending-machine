<template lang="">
    <div
        class="p-4 border-4 bg-white border-gray-200 border-dashed rounded-lg text-lg ls text-sky-800 flex gap-2"
    >
        <img
            src="/icon/dashboard/paperclip-clip.svg"
            class="w-6"
            alt=""
        /><slot></slot>
    </div>
</template>
<script>
export default {};
</script>
<style lang=""></style>
