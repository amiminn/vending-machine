<template lang="">
    <img src="/icon/loading.svg" alt="" class="w-20 animate-spin" />
</template>
